#include "util.h"

int64_t process_entry_data(char *file_name, char *partermeter, int start_offset, int numentries)
{
	int64_t i, entry_data;
	FILE *perfdata;
        perfdata = fopen(file_name, "r");
	for (i = 0; i< numentries; i++)
	{
		ENTRY_HEADERS ENTRY;
		int name_start,name_size,data_start;
		int64_t value;
		process_hexofile(perfdata, start_offset, sizeof(ENTRY_HEADERS), &ENTRY);
		name_start = start_offset + ENTRY.NAMEOFFSET;
		name_size = get_name_size(perfdata, name_start);
		char var_name[name_size];
		process_hexofile(perfdata,name_start, name_size, var_name);
		var_name[name_size-1] = '\0';
		data_start = start_offset + ENTRY.DATAOFFSET;
		process_hexofile(perfdata, data_start, sizeof(int64_t), &value);
		if (strcmp(var_name, partermeter) == 0)
		{
			entry_data=value;
			break;
		}
		start_offset += ENTRY.ENTRYLENGTH;

	}
	fclose(perfdata);
	return entry_data;
}
