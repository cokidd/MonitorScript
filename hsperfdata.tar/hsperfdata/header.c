#include "util.h"

int process_hexo_header(char *file_name)
{
	FILE *perfdata;
	PERFDATA_HEADER HEADER;
	perfdata = fopen(file_name, "r");
	process_hexofile(perfdata, PERFDATA_PROLOG_MAGIC_OFFSET, PERFDATA_PROLOG_BYTEORDER_OFFSET, &HEADER.MAGIC);
	process_hexofile(perfdata, PERFDATA_PROLOG_BYTEORDER_OFFSET, PERFDATA_PROLOG_BYTEORDER_SIZE, &HEADER.BYTEORDER);
	process_hexofile(perfdata, PERFDATA_PROLOG_MAJOR_OFFSET, PERFDATA_PROLOG_MAJOR_SIZE, &HEADER.MAJOR);
	process_hexofile(perfdata, PERFDATA_PROLOG_MINOR_OFFSET, PERFDATA_PROLOG_MINOR_SIZE, &HEADER.MINOR);
	if (SWAPENDIAN(HEADER.MAGIC) != PERFDATA_MAGIC)
	{
		err_sys("Bad Magic: %x\n", HEADER.MAGIC);
	}

	if (!(HEADER.MAJOR == 2 && HEADER.MINOR == 0))
	{
		err_sys( "Unsupported version %d.%d", HEADER.MAJOR, HEADER.MINOR);
	}
	fclose(perfdata);
	return 0;
}
