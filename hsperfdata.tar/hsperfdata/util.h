#include <stdio.h>
#include <glob.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/types.h>
#include <paths.h>
#include <errno.h>
#include <stdint.h>
#include <sys/types.h>
#include <paths.h>
#include <time.h>
#define MAXLINE 4096
#define MATCHKEY "/tmp/hsperfdata_root*"
#define SWAPENDIAN(A) (((A & 0x000000ff) << 24u)|\
		        ((A & 0x0000ff00) << 8u) |\
		        ((A & 0x00ff0000) >> 8u) |\
		        ((A & 0xff000000) >> 24u))
#define PERFDATA_PROLOG_OFFSET 0
#define PERFDATA_PROLOG_MAGIC_OFFSET 0
#define PERFDATA_PROLOG_BYTEORDER_OFFSET 4
#define PERFDATA_PROLOG_BYTEORDER_SIZE 1        // sizeof(byte)
#define PERFDATA_PROLOG_MAJOR_OFFSET 5
#define PERFDATA_PROLOG_MAJOR_SIZE 1            // sizeof(byte)
#define PERFDATA_PROLOG_MINOR_OFFSET 6
#define PERFDATA_PROLOG_MINOR_SIZE 1            // sizeof(byte)
#define PERFDATA_PROLOG_RESERVEDB1_OFFSET 7
#define PERFDATA_PROLOG_RESERVEDB1_SIZE 1       // sizeof(byte)
// these constants should match their #define counterparts in perfMemory.hpp

#define  PERFDATA_BIG_ENDIAN 0
#define  PERFDATA_LITTLE_ENDIAN 1
#define  PERFDATA_MAGIC   0xcafec0c0
#define  PERFDATA_MAJOR_NAME "sun.perfdata.majorVersion"
#define  PERFDATA_MINOR_NAME "sun.perfdata.minorVersion"

#define PERFDATA_PROLOG_ACCESSIBLE_OFFSET 7
#define PERFDATA_PROLOG_ACCESSIBLE_SIZE 1		// sizeof(byte)
#define PERFDATA_PROLOG_USED_OFFSET 8
#define PERFDATA_PROLOG_USED_SIZE 4			// sizeof(int)
#define PERFDATA_PROLOG_OVERFLOW_OFFSET 12
#define PERFDATA_PROLOG_OVERFLOW_SIZE 4			// sizeof(int)
#define PERFDATA_PROLOG_MODTIMESTAMP_OFFSET 16
#define PERFDATA_PROLOG_MODTIMESTAMP_SIZE 8		// sizeof(long)
#define PERFDATA_PROLOG_ENTRYOFFSET_OFFSET 24
#define PERFDATA_PROLOG_ENTRYOFFSET_SIZE 4		// sizeof(int)
#define PERFDATA_PROLOG_NUMENTRIES_OFFSET 28
#define PERFDATA_PROLOG_NUMENTRIES_SIZE 4        	// sizeof(int)
/*
 *	Process Header struct
 */

typedef struct 
{
	uint32_t		MAGIC;		// magic number - 0xcafec0c0
	unsigned char 		BYTEORDER; 	// big_endian == 0, little_endian == 1
	unsigned char		MAJOR;		// major version numbers
	unsigned char		MINOR;		// minor version numbers
} PERFDATA_HEADER;

typedef struct 
{
	unsigned char 		ACCESSIBLE;	// accessible flag at performance data v2
	int32_t			USED;		// number of perfdata memory bytes used
	int32_t			PROLOG_OVERFLOW;// number of bytes of overflow
	int64_t			MODTIMESTAMP;	// time stamp of the last structural modification
	int32_t			ENTRYOFFSET;	// offset of first perfdataentry
	int32_t			NUMENTRIES;	// number of allocated perfdata entries
} BUFFER_PROLOGUEV2;

typedef struct 
{
	int32_t			ENTRYLENGTH;	// entry length in bytes
	int32_t			NAMEOFFSET;	// offset to entry name, relative to start of entry
	int32_t			VECTORLENGTH;	// length of the vector. if 0, then scalar
	unsigned char		DATATYPE;	// jni field descriptor type
	unsigned char		FLAGS;		// miscellaneous attribute flags 0x01 - supported
	unsigned char		DATAUNITS;	// unit of measure attribute
	unsigned char		DATAVAR;	// variability attribute
	int32_t			DATAOFFSET;	// offset to data item, relative to start of entry.
} ENTRY_HEADERS;


/*
 *	ERROR PROCESS
 */ 
void err_msg(const char *, ...);
void err_dump(const char *, ...) __attribute__((noreturn));
void err_quit(const char *, ...) __attribute__ ((noreturn));
void err_cont(int, const char *, ...);
void err_exit(int, const char *, ...)__attribute__((noreturn));
void err_ret(const char *, ...);
void err_sys(const char *, ...)__attribute__((noreturn));

void match_paths(glob_t *);
int account_java_paths(void);
char** is_java_paths(void);
char **list_process_name(char *);
int account_process_number(char *);
char *full_path_name(char *, char *);
int process_hexofile(FILE * , long , int , void *);
int get_name_size(FILE *, long);
/*
 * 	PROCESS FILES DATA
 */
int process_hexo_header(char *);
void process_prolugue_hexo(char *, int *, int*, int*);
int64_t process_entry_data(char *, char *, int , int );

