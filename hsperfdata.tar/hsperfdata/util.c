#include "util.h"

/*
 * match path name == MATCH KEY
 */

void match_paths(glob_t *GLOBBUF)
{
	glob(MATCHKEY, GLOB_NOSORT, NULL, GLOBBUF); 
}

/*
 *	judge path exist status
 */

char **is_java_paths(void)
{
	int index;
	glob_t GLOBBUF;
	match_paths(&GLOBBUF);
	char **java_paths = (char **) malloc((GLOBBUF.gl_pathc) *sizeof(char *));
	for (index = 0; index < GLOBBUF.gl_pathc; index++)
	{
		java_paths[index] = (char *)malloc(sizeof(GLOBBUF.gl_pathv[index]));
		strcpy(java_paths[index],GLOBBUF.gl_pathv[index]);
	}
	globfree(&GLOBBUF);
	return java_paths;
}

/*
 * account user use java number
 */

int account_java_paths(void)
{
	glob_t GLOBBUF;
	match_paths(&GLOBBUF);
	int account = GLOBBUF.gl_pathc;
	return account;
}

/*
 * list java_paths process file
 */

char **list_process_name(char *java_path)
{	
	char *current_mark = ".";
	char *up_level_mark = "..";
	DIR *dp;
	int i = 0;
	struct dirent *dirp;
	int process_num = account_process_number(java_path);
	char **process_list = (char **) malloc((process_num) *sizeof(char *));
	if ((dp = opendir(java_path)) == NULL)
		err_sys("Can't open %s", java_path);
	while ((dirp = readdir(dp)) != NULL)
	{
		if((strcmp(dirp->d_name, current_mark)!=0) && (strcmp(dirp->d_name, up_level_mark)!= 0))
		{
			process_list[i] = (char *)malloc(sizeof(dirp->d_name));
			strcpy(process_list[i], dirp->d_name);
			i++;
			
		}
	}
	return process_list;
}

/*
 * account process number status 
 */ 

int account_process_number(char *java_path)
{
	DIR *dp;
	char *current_mark = ".";
	char *up_level_mark = "..";
	struct dirent *dirp;
	int account_process = 0;
	if ((dp = opendir(java_path)) == NULL)
		err_sys("Can't open %s", java_path);
	while ((dirp = readdir(dp)) != NULL)
	{
	 	if((strcmp(dirp->d_name, current_mark)!=0) && (strcmp(dirp->d_name, up_level_mark)!= 0))
			account_process++;
	}
	return account_process;
}

/*
 * connect paths and file name together
 */

char *full_path_name(char *java_path, char *process_num)
{
	char *dir_mark = "/";
	char *target_path=(char*)malloc(32);
	strcpy(target_path, java_path);
        strcat(target_path, dir_mark);
	strcat(target_path, process_num);
	return target_path;
}
int process_hexofile(FILE * stream, long offset, int size, void *buffer)
{
        fseek(stream, offset, SEEK_SET);
        fread(buffer, size, 1, stream);
        return 0;

}
int get_name_size(FILE * stream, long offset)
{
	int end_increase;
	int8_t mark;
	fseek(stream, offset, SEEK_SET);
	for (end_increase = 0; mark != 0x00; end_increase++, offset++)
	{
		fread(&mark, 1, 1, stream);
		fseek(stream, offset, SEEK_SET);
	}
	return end_increase+1;
}
