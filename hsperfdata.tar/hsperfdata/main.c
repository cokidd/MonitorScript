#include "util.h"
void service_status(void);

int main(int argc, char *argv[])
{
	if (argc == 1)
	{
		service_status();
		
	}
	if (argc == 2)
	{
		printf("%s\n", argv[1]);
	}
	else if (argc > 3)
	{
		printf("too many paramters");
	}
	else if (argc == 3)
	{
		printf("The arguments supplied are:\n");
		printf("%s\t", argv[0]);
		printf("%s\t", argv[1]);
		printf("%s\t", argv[2]);
	}
	return 0;
}

void service_status(void)
{
	char** java_paths = is_java_paths();
	int account = account_java_paths();
	int i, j, account_process_num;
	time_t tmpcal_ptr;
	time(&tmpcal_ptr);
	printf("{\n       \"data\":[\n");
	for (i = 0; i < account; i++)
	{
		account_process_num = account_process_number(java_paths[i]);
		if (account_process_num == 0)
		{
			printf("              {\n                     \"{#PID}\":\"0\"\n              },\n");
		}
		else
		{
			char **process_list=list_process_name(java_paths[i]);
			for(j = 0; j < account_process_num; j++)
			{
				printf("              {\n                     \"{#PID}\":\"%s\"\n              },\n", process_list[j] );
			}
		}
	}
	printf("              {\n                     \"{#DATE}\":\"%ld\"\n              }\n", tmpcal_ptr);
	printf("       ]\n");
	printf("}\n");
	free(java_paths);
}

